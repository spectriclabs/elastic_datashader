export function getDefaultProperties(mapColors = []) {
    return {
      colorRampName: "bmy",
      spread: 1,
      spanRange: "auto",
      mode: "heat",
      categoryField: null
    };
  }