export function getDefaultProperties(mapColors = []) {
    return {
      colorRampName: "bmy",
      colorKeyName: "glasbey_light",
      spread: "auto",
      spanRange: "normal",
      gridResolution: "finest",
      mode: "heat",
      categoryField: "",
      categoryFieldType: null,
      categoryFieldPattern: null,
      showEllipses: false,
      useHistogram: undefined,
      ellipseMajorField: "",
      ellipseMinorField: "",
      ellipseTiltField: "",
      ellipseUnits: "semi_majmin_nm",
      ellipseSearchDistance: "normal",
      manualResolution: false,
    };
  }